
<div class="menu-mobile-container">
	<div class="header-menu">
		<div class="row-fluid">
			<div class="span4">
				<div class="panel-logo">{module mod-logo-mobile}</div>
			</div>
			<div class="span8">
				<div class="panel-toggle">
					<i class="fa fa-reorder"> </i>
				</div>
			</div>
		</div>
	</div>
<div class="body-menu">
	{module menu-mobile-top}
</div>
</div>
