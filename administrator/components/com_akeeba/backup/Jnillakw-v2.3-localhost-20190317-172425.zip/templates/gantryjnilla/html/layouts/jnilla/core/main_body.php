<?php
defined('JPATH_BASE') or die;

// init
global $gantry;
?>
<?php // main body positions ?>
<?php echo $gantry->displayMainbody('mainbody','sidebar','standard','standard','standard','standard','standard'); ?>

