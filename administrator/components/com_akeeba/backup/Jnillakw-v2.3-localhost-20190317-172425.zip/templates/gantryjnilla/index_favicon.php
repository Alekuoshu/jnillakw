<?php
if($jnilla->developmentMode) $uniqid = "?uniqid=".$jnilla->uniqid;
?>
<link rel="apple-touch-icon" href="templates/<?php echo $templateName ;?>/favicon/apple-touch-icon.png<?php echo $uniqid; ?>" sizes="180x180">
<link rel="icon" type="image/png" href="templates/<?php echo $templateName ;?>/favicon/favicon-32x32.png<?php echo $uniqid; ?>" sizes="32x32">
<link rel="icon" type="image/png" href="templates/<?php echo $templateName ;?>/favicon/favicon-16x16.png<?php echo $uniqid; ?>" sizes="16x16">


