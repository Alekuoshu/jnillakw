
<div class="template-preview">
	<h1>GantryJnilla</h1>
	<p><img src="<?php echo $gantry->templateUrl;?>/logo.png" /></p>
	<p>Read the documentation <a target='_blank' href='https://docs.google.com/document/d/1fwoWNdjGUZXvyGXyqzgGibaM6pZFhA_t-k9fc_2Cvu0/edit#heading=h.i0egaowm03c3'>Here</a></p>
</div>
<div class="template-description">
	<h2>Template Layout System Preview</h2>
	<img src="<?php echo $gantry->templateUrl;?>/layout-system.png" />
</div>
